// ============================================================================
// estado.js — Máquina de estados, control del enjambre, overlay Panel 3
// ============================================================================

// ── Máquina de estados ────────────────────────────────────────────────────────

function transicionar(nuevoEstado) {
  if (nuevoEstado !== estado) {
    console.log(`[Estado] ${estado} → ${nuevoEstado}`);
    estado = nuevoEstado;
  }
}

function enEstado(...estados) {
  return estados.includes(estado);
}

function iniciarEntrenamiento() {
  console.log('[Transición] iniciarEntrenamiento()');
  if (modelos && modelos.length > 0) {
    const vals = modelos.map(m =>
      m.historial && m.historial.length > 0 ? m.historial[0].J_train : 1.0);
    J_max_epoca0 = Math.max(...vals, 0.01);
  } else {
    J_max_epoca0 = 1.0;
  }

  let mejorJ = Infinity, mejorRef = 0;
  for (let i = 0; i < modelos.length; i++) {
    const h0 = modelos[i].historial;
    if (h0 && h0.length > 0 && h0[0].J_test < mejorJ) {
      mejorJ = h0[0].J_test; mejorRef = i;
    }
  }
  modeloReferencia = mejorRef;
  transicionar('RUNNING');
  actualizarUIEstado();
}

function detener() {
  console.log('[Transición] detener()');
  transicionar('PAUSED');
  actualizarUIEstado();
}

function continuar() {
  console.log('[Transición] continuar()');
  transicionar('RUNNING');
  actualizarUIEstado();
}

function converger() {
  console.log('[Transición] converger()');
  transicionar('CONVERGED');
  actualizarUIEstado();
}

function reiniciar() {
  console.log('[Transición] reiniciar()');
  transicionar('IDLE');
  actualizarUIEstado();
  modeloReferencia         = null;
  distribucionSeleccionada = null;
  _epochTarget             = null;
  initEnjambre();
}

function resetear() {
  console.log('[Transición] resetear()');
  transicionar('IDLE');
  actualizarUIEstado();
  modeloReferencia         = null;
  distribucionSeleccionada = null;
  _epochTarget             = null;
  initEnjambre();
}

function avanzar100() {
  if (enEstado('CONVERGED')) return;
  const epActual = modelos.length > 0
    ? Math.max(...modelos.map(m => m.historial.length)) : 0;
  _epochTarget = epActual + 100;
  if (enEstado('IDLE'))   iniciarEntrenamiento();
  else if (enEstado('PAUSED')) { transicionar('RUNNING'); actualizarUIEstado(); }
}

function notificar(texto) {
  notificacion = { texto, frameInicio: frameCount, duracion: 120 };
  console.log(`[Notificación] ${texto}`);
}

// ── Control del enjambre ─────────────────────────────────────────────────────

function pasosPorFrame() {
  if (velocidad === 'lenta')  return 1;
  if (velocidad === 'rapida') return 25;
  return 5;
}

function stepModelo(m) {
  if (m.estado !== 'activo') return;

  const J_ant = m.historial.length > 0
    ? m.historial[m.historial.length - 1].J_train : Infinity;

  entrenarEpoca(m, datosTrain);

  const { diverge } = verificarDivergencia(m, J_ant);
  if (diverge) {
    const grid = calcularGridPrediccion(m, 50);
    m.frontera = calcularFrontera(grid, 50);
    m.estado = 'divergente';
    return;
  }
  if (m.historial.length >= maximoEpocas) {
    const grid = calcularGridPrediccion(m, 50);
    m.frontera = calcularFrontera(grid, 50);
    m.estado = 'no_convergido';
    return;
  }
  if (verificarConvergencia(m)) {
    const grid = calcularGridPrediccion(m, 50);
    m.frontera = calcularFrontera(grid, 50);
    m.estado = 'convergido';
    m.epocaFinal = m.historial.length;
  }
}

function initEnjambre() {
  if      (moduloActivo === 'eta')        generarEnjambreEta(etaMinVal, etaMaxVal, nModelosEta);
  else if (moduloActivo === 'init')       generarEnjambreInit();
  else if (moduloActivo === 'activacion') generarEnjambreActivacion();
  else if (moduloActivo === 'dropout')    generarEnjambreDropout();
  else if (moduloActivo === 'topologia')  generarEnjambreTopologia();
}

function dibujarControlesPanel3() {
  if (!modelos || modelos.length === 0) return;
  const r3 = panelRect(3);
  if      (moduloActivo === 'eta')        dibujarCirculosEta(r3);
  else if (moduloActivo === 'init')       dibujarCirculosInit(r3);
  else if (moduloActivo === 'activacion') dibujarCirculosActivacion(r3);
  else if (moduloActivo === 'dropout')    dibujarCirculosDropout(r3);
  else if (moduloActivo === 'topologia')  dibujarCirculosTopologia(r3);
}

// ── Overlay Panel 3 (DOM) ─────────────────────────────────────────────────────

function crearOverlayPanel3() {
  let overlay = document.getElementById('panel3-overlay');
  if (overlay) overlay.remove();

  overlay = document.createElement('div');
  overlay.id = 'panel3-overlay';
  // Solo el botón principal es común a todos los módulos
  overlay.innerHTML = `
    <button id="btn-principal">Entrenar enjambre</button>
    <hr class="p3-sep">
  `;
  document.body.appendChild(overlay);

  document.getElementById('btn-principal').addEventListener('click', () => {
    if      (enEstado('IDLE'))      iniciarEntrenamiento();
    else if (enEstado('RUNNING'))   detener();
    else if (enEstado('PAUSED'))    continuar();
    else if (enEstado('CONVERGED')) reiniciar();
  });

  // Cada módulo añade su sección
  crearSeccionOverlayEta();
  crearSeccionOverlayInit();
  crearSeccionOverlayActivacion();
  crearSeccionOverlayDropout();
  crearSeccionOverlayTopologia();

  posicionarOverlayPanel3();
}

function actualizarModuloOverlay() {
  ['eta', 'init', 'activacion', 'dropout', 'topologia'].forEach(mod => {
    const div = document.getElementById(`controles-${mod}`);
    if (div) div.style.display = moduloActivo === mod ? 'block' : 'none';
  });
}

function actualizarUIEstado() {
  // Botón principal (común)
  const btn = document.getElementById('btn-principal');
  if (btn) {
    const etiquetas = {
      IDLE: 'Entrenar enjambre', RUNNING: 'Detener',
      PAUSED: 'Continuar',       CONVERGED: 'Reiniciar'
    };
    btn.textContent = etiquetas[estado] || 'Entrenar enjambre';
  }

  // Barra global (común)
  const enMovimiento = enEstado('RUNNING', 'PAUSED');
  ['select-problema', 'slider-ruido', 'slider-train', 'btn-semilla'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.disabled = enMovimiento;
  });

  // Cada módulo actualiza sus propios controles
  actualizarUIEstadoEta();
  actualizarUIEstadoInit();
  actualizarUIEstadoActivacion();
  actualizarUIEstadoDropout();
  actualizarUIEstadoTopologia();
}
